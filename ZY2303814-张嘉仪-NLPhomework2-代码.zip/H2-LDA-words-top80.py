import numpy as np
import random
import ast
import os
import csv
from sklearn.svm import SVC
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt

csv.field_size_limit(500 * 1024 * 1024)


class LDA:
    def __init__(self, data_txt, topic_count):
        self.data_txt = data_txt
        #print(len(self.data_txt))
        self.topic_count = topic_count
        self.topic_word_count = {}  # 每个topic有多少词
        self.topic_word_fre = {}  # 每个topic的词频表，字典的列表
        for i in range(self.topic_count):
            self.topic_word_fre[i] = self.topic_word_fre.get(i, {})
        self.doc_word_from_topic = []  # 每篇文章中的每个词来自哪个topic
        self.doc_word_count = []  # 每篇文章中有多少词
        self.doc_topic_fre = []  # 每篇文章topic词频
        for data in self.data_txt:
            topic = []
            docfre = {}
            for word in data:
                a = random.randint(0, self.topic_count - 1)  # 为每个单词赋予一个随机初始topic
                topic.append(a)
                if '\u4e00' <= word <= '\u9fa5':
                    self.topic_word_count[a] = self.topic_word_count.get(a, 0) + 1  # 统计每个topic总词数
                    docfre[a] = docfre.get(a, 0) + 1  # 统计每篇文章对应topic的词频
                    self.topic_word_fre[a][word] = self.topic_word_fre[a].get(word, 0) + 1
            self.doc_word_from_topic.append(topic)
            for i in range(self.topic_count):
                docfre[i] = docfre.get(i, 0)
            docfre = list(dict(sorted(docfre.items(), key=lambda x: x[0], reverse=False)).values())
            self.doc_topic_fre.append(docfre)
            self.doc_word_count.append(sum(docfre))  # 统计每篇文章的总词数
        self.topic_word_count = list(
            dict(sorted(self.topic_word_count.items(), key=lambda x: x[0], reverse=False)).values())
        self.doc_topic_fre = np.array(self.doc_topic_fre)  # 转为array方便后续计算
        self.topic_word_count = np.array(self.topic_word_count)  # 转为array方便后续计算
        self.doc_word_count = np.array(self.doc_word_count)  # 转为array方便后续计算
        self.doc_topic_pro = []  # 每个topic被选中的概率
        self.doc_topic_pro_new = []  # 记录每次迭代后每个topic被选中的概率
        self.doc_topic_pro_new_test = []
        self.cal_pro()

    def cal_pro(self):
        # 计算一篇文章中每个topic被选中的概率
        for i in range(len(self.data_txt)):
            #print(len(self.data_txt))
            #print(self.doc_topic_fre[i])
            #print(self.doc_word_count[i])
            doc = np.divide(self.doc_topic_fre[i], self.doc_word_count[i])
            self.doc_topic_pro.append(doc)

    def train(self):
        stop = 0  # 迭代停止标志
        loopcount = 1  # 迭代次数
        while stop == 0:
            i = 0
            for data in self.data_txt:
                top = self.doc_word_from_topic[i]
                for w in range(len(data)):
                    word = data[w]
                    pro = []
                    topfre = []
                    if '\u4e00' <= word <= '\u9fa5':
                        for j in range(self.topic_count):
                            topfre.append(self.topic_word_fre[j].get(word, 0))
                        pro = self.doc_topic_pro[i] * topfre / self.topic_word_count  # 计算每篇文章选中各个topic的概率乘以该词语在每个topic中出现的概率，得到该词出现的概率向量
                        m = np.argmax(pro)  # 认为该词是由上述概率之积最大的那个topic产生的
                        self.doc_topic_fre[i][top[w]] -= 1  # 更新每个文档有多少各个topic的词
                        self.doc_topic_fre[i][m] += 1
                        self.topic_word_count[top[w]] -= 1  # 更新每个topic的总词数
                        self.topic_word_count[m] += 1
                        self.topic_word_fre[top[w]][word] = self.topic_word_fre[top[w]].get(word, 0) - 1  # 统计每个topic总词数
                        self.topic_word_fre[m][word] = self.topic_word_fre[m].get(word, 0) + 1  # 统计每个topic总词数
                        top[w] = m
                self.doc_word_from_topic[i] = top
                i += 1
            if loopcount == 1:  # 计算新的每篇文章选中各个topic的概率
                for i in range(len(self.data_txt)):
                    doc = np.divide(self.doc_topic_fre[i], self.doc_word_count[i])
                    self.doc_topic_pro_new.append(doc)
                self.doc_topic_pro_new = np.array(self.doc_topic_pro_new)
            else:
                for i in range(len(self.data_txt)):
                    doc = np.divide(self.doc_topic_fre[i], self.doc_word_count[i])
                    self.doc_topic_pro_new[i] = doc
            if (self.doc_topic_pro_new == self.doc_topic_pro).all():  # 如果每篇文章选中各个topic的概率不再变化，则认为模型已经训练完毕
                stop = 1
            else:
                self.doc_topic_pro = self.doc_topic_pro_new.copy()
            loopcount += 1
            #print(loopcount)
        #print(self.doc_topic_pro_new)  # 输出最终训练的到的每篇文章选中各个topic的概率
        #print('模型训练完毕！')

    def test(self, test_txt):
        doc_word_from_topic = []  # 每篇文章中的每个词来自哪个topic
        doc_word_count = []  # 每篇文章中有多少词
        doc_topic_fre = []  # 每篇文章topic词频
        i = 0
        for data in test_txt:
            topic = []
            docfre = {}
            for word in data:
                a = random.randint(0, self.topic_count - 1)  # 为每个单词赋予一个随机初始topic
                topic.append(a)
                if '\u4e00' <= word <= '\u9fa5':
                    docfre[a] = docfre.get(a, 0) + 1  # 统计每篇文章的词频
            doc_word_from_topic.append(topic)
            for i in range(self.topic_count):
                docfre[i] = docfre.get(i, 0)
            docfre = list(dict(sorted(docfre.items(), key=lambda x: x[0], reverse=False)).values())
            doc_topic_fre.append(docfre)
            doc_word_count.append(sum(docfre))  # 统计每篇文章的总词数
            i += 1

        doc_topic_fre = np.array(doc_topic_fre)
        doc_word_count = np.array(doc_word_count)

        doc_topic_pro = []  # 每个topic被选中的概率
        doc_topic_pro_new = []  # 记录每次迭代后每个topic被选中的新概率
        for i in range(len(test_txt)):
            doc = np.divide(doc_topic_fre[i], doc_word_count[i])
            doc_topic_pro.append(doc)
        doc_topic_pro = np.array(doc_topic_pro)

        stop = 0  # 迭代停止标志
        loopcount = 1  # 迭代次数
        while stop == 0:
            i = 0
            for data in test_txt:
                top = doc_word_from_topic[i]
                for w in range(len(data)):
                    word = data[w]
                    pro = []
                    topfre = []
                    if '\u4e00' <= word <= '\u9fa5':
                        for j in range(self.topic_count):
                            topfre.append(self.topic_word_fre[j].get(word, 0))
                            # exec('topfre.append(Topic_fre{}.get(word, 0))'.format(j))  # 读取该词语在每个topic中出现的频数

                        pro = doc_topic_pro[i] * topfre / self.topic_word_count  # 计算每篇文章选中各个topic的概率乘以该词语在每个topic中出现的概率，得到该词出现的概率向量
                        m = np.argmax(pro)  # 认为该词是由上述概率之积最大的那个topic产生的
                        doc_topic_fre[i][top[w]] -= 1  # 更新每个文档有多少各个topic的词
                        doc_topic_fre[i][m] += 1
                        top[w] = m
                doc_word_from_topic[i] = top
                i += 1

            if loopcount == 1:  # 计算新的每篇文章选中各个topic的概率
                for i in range(len(test_txt)):
                    doc = np.divide(doc_topic_fre[i], doc_word_count[i])
                    doc_topic_pro_new.append(doc)
                doc_topic_pro_new = np.array(doc_topic_pro_new)
            else:
                for i in range(len(test_txt)):
                    doc = np.divide(doc_topic_fre[i], doc_word_count[i])
                    doc_topic_pro_new[i] = doc

            if (doc_topic_pro_new == doc_topic_pro).all():  # 如果每篇文章选中各个topic的概率不再变化，则认为训练集已分类完毕
                stop = 1
            else:
                doc_topic_pro = doc_topic_pro_new.copy()
            loopcount += 1
        self.doc_topic_pro_new_test = doc_topic_pro.copy()
        #print(loopcount)
        #print('测试集测试完毕！')
        result = []
        for k in range(len(test_txt)):
            pro = []
            for i in range(len(self.data_txt)):
                dis = 0
                for j in range(self.topic_count):
                    dis += (self.doc_topic_pro[i][j] - doc_topic_pro[k][j]) ** 2  # 计算欧式距离
                pro.append(dis)
            m = pro.index(min(pro))
            result.append(m)  # 表示测试集文档 k 被分配到了训练集文档 m 的主题
        #print(result)
        return result


def select_paragraphs(data,labels, token):
    novel_new = []  # 存储切片labels后的数据
    label_new = []  # 存储切片后的标签列表

    # 遍历每个文档中的行
    for i, line in enumerate(data):
        #print(line)
        paragraph = []  # 存储当前行的词
        label_paragraph = []  # 存储当前行的标签
        # 遍历当前行中的每个词及其对应的标签
        for word in line:
            #print(word)
            #print(len(paragraph))
            if len(paragraph) < token:  # 确保只选择当前行的前token个词
                paragraph.append(word)
                label_paragraph.append(labels[i])

            if len(paragraph) == token:  # 达到token个词时，将其保存并重置
                novel_new.append(paragraph)
                label_new.append(label_paragraph)
                paragraph = []  # 重置当前行的词列表
                label_paragraph = []  # 重置当前行的标签列表

    return novel_new, label_new


def load_data(filename,token):
    data_t = []
    labels = []
    with open(filename, 'r', encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            number = row[0]  # 假设第一列是数字ID
            label = row[1]  # 假设第二列是标签
            # 假设第三列是data字段，需要进行解析
            data_str = row[2]  # 获取data列的原始字符串
            # 移除字符串中的所有换行符和额外的引号
            # if token == 1000 or token == 3000:
            #     data_str = data_str
            # else:
            #     data_str = data_str.replace('\n', '').replace('\'', '"').strip('"')
            #print(data_str)
            try:
                data = ast.literal_eval(data_str)
            except ValueError as e:
                print(f"Error parsing data_str: {data_str}")
                print(f"Exception: {e}")
            data_t.append(data)
            labels.append(label)
    return data_t, labels

if __name__ == "__main__":

    token_accuracies = []
    token = [20, 100, 500, 1000, 3000]
    Topics = 80 #20, 50, 80, 120, 140
    type = 'words'
    #svm_classifier = SVC(kernel='linear', random_state=42)
    kf = KFold(n_splits=10, shuffle=True, random_state=42)#10次交叉验证
    for j in range(len(token)):
        print("token:", token[j])
        print("Topics:", Topics)
        print("------" + type + "------")
        data_txt, labels = load_data(str(token[j]) + '-' + type + '-new.csv', token[j])
        # print(len(data_txt))
        data_txt_new, labels = select_paragraphs(data_txt, labels, token[j])

        result = []

        # 计算训练集准确度和测试集准确度
        train_accuracies = []
        test_accuracies = []
        result_record = []
        result_ave = 0

        for train_index, test_index in kf.split(range(len(data_txt_new))):

            train_data = [data_txt_new[i] for i in train_index]
            test_data = [data_txt_new[i] for i in test_index]
            train_labels = [labels[i] for i in train_index]
            test_labels = [labels[i] for i in test_index]


            lda = LDA(train_data, Topics)
            lda.train()
            result = lda.test(test_data)


            tr = 0
            error = 0
            for i in range(len(result)):

                if result[i] < len(train_index) and test_labels[i] == train_labels[result[i]]:
                    tr += 1
                else:
                    error += 1

            result_ave += tr/(tr+error)
            result_record.append(tr/(tr+error))



        print("for roken:", end='')
        print(token[j])
        # print("分类方法1：")
        print("记录正确：", result_record)
        result_ave = result_ave/10
        token_accuracies.append(result_ave)
        print("平均分类正确比例：", result_ave)

    # 绘制 token_accuracies 的折线图
    plt.figure(figsize=(10, 6))
    plt.plot(token, token_accuracies, marker='o', label='Euclidean distance Classification Accuracy')  # 添加图例
    # plt.plot(token, svm_results_test, marker='x', linestyle='--', label='SVM Classification Accuracy')  # 添加 SVM 结果和图例

    plt.xlabel('Token Count')
    plt.ylabel('Average Classification Accuracy')
    title = 'In case Topic = ' + str(Topics) + 'type=' + type
    plt.title(title)

    # 添加图例
    plt.legend()

    # 构建文件名
    filename = f"token{min(token)}_to_{max(token)}_topic{Topics}_{type}_pic.png"
    plt.savefig('pic/' + filename)
    plt.close()  # 关闭图形，以便于保存下一张图

    # 确保结果目录存在
    os.makedirs('result', exist_ok=True)

    # 构建文件名
    filename2 = f"token{min(token)}_to_{max(token)}_topic{Topics}_{type}_result.txt"
    result_file_path = os.path.join('result', filename2)

    # 打开文件以写入结果
    with open(result_file_path, 'w') as result_file:
        for tok, acc in zip(token, token_accuracies):
            # 写入每个 token 和对应的 result_ave 到文件，格式为：token: accuracy
            result_file.write(f"{tok}: {acc}\n")

    # 文件将在 with 块结束时自动关闭